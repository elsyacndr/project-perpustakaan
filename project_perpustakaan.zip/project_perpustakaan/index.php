<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI Perpus UNS</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #F4F4F9;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .navbar {
            background-color: #5D5FEF;
        }
        .navbar-brand {
            color: white;
            font-weight: 700;
        }
        .navbar-nav .nav-link {
            color: white;
            font-weight: 500;
            margin-right: 15px;
        }
        .jumbotron {
            background: linear-gradient(135deg, #5D5FEF, #8B80F9);
            color: white;
            padding: 5rem 2rem;
            margin-top: 40px;
            border-radius: 0;
        }
        .jumbotron h1 {
            font-weight: 700;
            font-size: 3rem;
        }
        .jumbotron p.lead {
            font-size: 1.2rem;
            font-weight: 400;
        }
        .btn-primary {
            background-color: #FF6B6B;
            border-color: #FF6B6B;
            font-weight: 600;
        }
        .btn-primary:hover {
            background-color: #FF4B4B;
            border-color: #FF4B4B;
        }
        footer {
            background-color: #5D5FEF;
            color: white;
            font-size: 0.9rem;
            padding: 1rem 0;
            margin-top: 40px;
        }
        .container-fluid {
            padding-left: 0;
            padding-right: 0;
        }
        .content-wrapper {
            padding-bottom: 40px;
        }
    </style>
</head>
<body>

<div class="container-fluid content-wrapper">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#">SI Perpus UNS</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="views/register.php">Register</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="views/login.php">Member Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="views/login.php">Admin Dashboard</a> <!-- Mengarah ke login -->
                </li>
            </ul>
        </div>
    </nav>

    <!-- Banner atau pengenalan perpustakaan -->
    <div class="jumbotron text-center">
        <h1 class="display-4">Selamat Datang di SI Perpus UNS</h1>
        <p class="lead">Aplikasi perpustakaan untuk memudahkan pengelolaan buku, peminjaman, dan keanggotaan.</p>
        <hr class="my-4" style="border-color: rgba(255, 255, 255, 0.2);">
        <p>Jelajahi koleksi buku terbaru kami dan daftarkan diri Anda sebagai anggota.</p>
        <a class="btn btn-primary btn-lg" href="views/register.php" role="button">Daftar Sekarang</a>
    </div>
</div>

<!-- Footer -->
<footer class="text-center">
    <div class="container-fluid">
        <p>&copy; 2024 SI Perpus UNS. All rights reserved.</p>
        <p>ELSYA CANDRA NIHAYA FIRDAUS/K3522025</p>
    </div>
</footer>

<!-- Bootstrap JS and dependencies -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
