<?php
include '../config/db.php'; // Koneksi ke database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Enkripsi password
    $role = $_POST['role'];

    // Query untuk memasukkan data ke tabel pengguna
    $sql = "INSERT INTO pengguna (nama, email, password, role) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$nama, $email, $password, $role]);

    if ($stmt) {
        header('Location: ../views/view_user.php'); // Redirect ke halaman daftar pengguna
    } else {
        echo "Terjadi kesalahan saat menambahkan pengguna.";
    }
}
?>
