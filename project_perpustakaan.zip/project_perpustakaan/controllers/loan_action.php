<?php
session_start();
include '../config/db.php'; // Koneksi ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $id_buku = $_POST['id_buku'];
    $id_pengguna = $_POST['id_pengguna'];
    $tanggal_pinjam = date('Y-m-d');

    // Validasi input
    if (!empty($id_buku) && !empty($id_pengguna)) {
        // Siapkan pernyataan untuk memasukkan data peminjaman
        $sql = "INSERT INTO peminjaman (id_buku, id_pengguna, tanggal_pinjam) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);

        // Eksekusi pernyataan dan tangani error
        try {
            $stmt->execute([$id_buku, $id_pengguna, $tanggal_pinjam]);
            $_SESSION['success'] = "Peminjaman buku berhasil!";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Terjadi kesalahan: " . $e->getMessage();
        }
    } else {
        $_SESSION['error'] = "Semua field harus diisi!";
    }

    // Redirect kembali ke halaman peminjaman
    header("Location: loan_book.php");
    exit();
}
