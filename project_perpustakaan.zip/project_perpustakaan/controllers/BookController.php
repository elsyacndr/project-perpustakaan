<?php
session_start();
include '../config/db.php'; // Koneksi ke database

class BookController {
    public function viewBooks() {
        global $conn; // Menggunakan koneksi dari config/db.php

        // Mengambil semua buku dari database
        $sql = "SELECT * FROM buku";
        $stmt = $conn->query($sql);
        $books = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Memasukkan data buku ke view
        include '../views/view_books.php';
    }
}

// Membuat instance BookController dan memanggil method viewBooks
$controller = new BookController();
$controller->viewBooks();
?>