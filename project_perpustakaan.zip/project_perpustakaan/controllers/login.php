<form method="POST" action="../views/login.php">
    <input type="email" name="email" placeholder="Email">
    <input type="password" name="password" placeholder="Password">
    <button type="submit">Login</button>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Cek koneksi database
    include '../config/db.php'; // Path ke koneksi database

    // Validasi user dari database
    $sql = "SELECT * FROM pengguna WHERE email = :email";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user['role'] == 'admin') {
        header("Location: ../views/member_dashboard.php");
    } else {
        header("Location: ../views/admin_dashboard.php");
    }
    exit();
} else {
    // Jika password salah, tampilkan pesan error
    $error = "Email atau password salah.";
}
?>
