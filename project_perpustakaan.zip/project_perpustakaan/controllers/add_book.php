<form action="../controllers/add_book_action.php" method="POST">
    <label for="id_buku">ID Buku:</label>
    <input type="number" name="id_buku" required><br>

    <label for="judul">Judul Buku:</label>
    <input type="text" name="judul" required><br>

    <label for="pengarang">Pengarang:</label>
    <input type="text" name="pengarang" required><br>

    <label for="tahun_terbit">Tahun Terbit:</label>
    <input type="number" name="tahun_terbit" required><br>

    <label for="id_rak">ID Rak:</label>
    <input type="number" name="id_rak" required><br>

    <button type="submit">Tambah Buku</button>
</form>