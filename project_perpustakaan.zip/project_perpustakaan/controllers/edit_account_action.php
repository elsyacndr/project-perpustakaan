<?php
session_start();
include '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pengguna = $_POST['id_pengguna'];
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Siapkan query untuk memperbarui data
    $sql = "UPDATE pengguna SET nama = ?, email = ?";
    $params = [$nama, $email];

    // Jika password diisi, tambahkan ke query
    if (!empty($password)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $sql .= ", password = ?";
        $params[] = $password_hash;
    }

    // Lengkapi query dengan WHERE clause
    $sql .= " WHERE id_pengguna = ?";
    $params[] = $id_pengguna;

    // Eksekusi query
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    // Redirect setelah berhasil
    header("Location: ../views/admin_dashboard.php?message=Data berhasil diperbarui");
    exit();
}
