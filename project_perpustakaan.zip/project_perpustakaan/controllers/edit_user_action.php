<?php
include '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['id'])) {
    $id = $_GET['id'];
    $nama = $_POST['nama'];
    $email = $_POST['email'];

    $sql = "UPDATE pengguna SET nama = ?, email = ? WHERE id_pengguna = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$nama, $email, $id]);

    header("Location: view_user.php");
}
?>
