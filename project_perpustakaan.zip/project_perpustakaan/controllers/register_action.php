<?php
include '../config/db.php';
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password

    // Perbarui kueri untuk memasukkan tanggal_daftar
    $sql = "INSERT INTO pengguna (nama, email, password, role, tanggal_daftar) VALUES (?, ?, ?, 'user', NOW())";
    $stmt = $conn->prepare($sql);

    // Eksekusi pernyataan dengan data yang sesuai
    $stmt->execute([$nama, $email, $password]);

    // Redirect ke halaman utama setelah pendaftaran berhasil
    header("Location: ../index.php");
}
?>
