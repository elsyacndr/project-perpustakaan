<?php
session_start();
include '../config/db.php'; // Koneksi ke database

if (isset($_GET['id'])) {
    $id_peminjaman = $_GET['id'];

    // Hapus transaksi dari tabel peminjaman
    $sql = "DELETE FROM peminjaman WHERE id_peminjaman = :id_peminjaman";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_peminjaman', $id_peminjaman);

    if ($stmt->execute()) {
        // Redirect ke halaman transaksi dengan pesan sukses
        $_SESSION['message'] = "Transaksi berhasil dihapus.";
        header('Location: ../views/transactions.php'); // Ubah sesuai dengan struktur folder
        exit();
    } else {
        // Redirect dengan pesan error
        $_SESSION['error'] = "Terjadi kesalahan saat menghapus transaksi.";
        header('Location: ../views/transactions.php');
        exit();
    }
} else {
    // Jika ID tidak ada, redirect dengan pesan error
    $_SESSION['error'] = "ID peminjaman tidak ditemukan.";
    header('Location: ../views/transactions.php');
    exit();
}
