<?php
include 'db.php';

try {
    // Membuat tabel rak
    $pdo->exec("CREATE TABLE IF NOT EXISTS rak (
        id_rak INT(11) NOT NULL AUTO_INCREMENT,
        lokasi VARCHAR(255) NOT NULL,
        PRIMARY KEY (id_rak)
    ) ENGINE=InnoDB");

    // Membuat tabel buku
    $pdo->exec("CREATE TABLE IF NOT EXISTS buku (
        id_buku INT(11) NOT NULL AUTO_INCREMENT,
        judul VARCHAR(255) NOT NULL,
        pengarang VARCHAR(255) NOT NULL,
        tahun_terbit YEAR NOT NULL,
        id_rak INT(11),
        PRIMARY KEY (id_buku),
        FOREIGN KEY (id_rak) REFERENCES rak(id_rak) ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB");

    // Membuat tabel pengguna
    $pdo->exec("CREATE TABLE IF NOT EXISTS pengguna (
        id_pengguna INT(11) NOT NULL AUTO_INCREMENT,
        nama VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'user') NOT NULL,
        PRIMARY KEY (id_pengguna)
    ) ENGINE=InnoDB");

    // Membuat tabel peminjaman
    $pdo->exec("CREATE TABLE IF NOT EXISTS peminjaman (
        id_peminjaman INT(11) NOT NULL AUTO_INCREMENT,
        id_pengguna INT(11),
        id_buku INT(11),
        tanggal_pinjam DATE,
        tanggal_kembali DATE,
        PRIMARY KEY (id_peminjaman),
        FOREIGN KEY (id_pengguna) REFERENCES pengguna(id_pengguna) ON DELETE CASCADE ON UPDATE CASCADE,
        FOREIGN KEY (id_buku) REFERENCES buku(id_buku) ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS absen (
        id_pengguna INT(11),
        nama VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        tanggal_absen DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_pengguna) REFERENCES pengguna(id_pengguna)
    ) ENGINE=InnoDB");

    echo "Tabel berhasil dibuat!";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
