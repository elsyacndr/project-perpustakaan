<?php
$host = 'localhost';
$dbname = 'perpustakaan';
$username = 'root'; // ganti dengan username Anda
$password = ''; // ganti dengan password Anda

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
