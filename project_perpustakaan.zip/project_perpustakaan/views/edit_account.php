<?php
session_start();
include '../config/db.php';

// Pastikan user_id ada di session
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php"); // Redirect jika tidak ada session
    exit();
}

// Ambil ID pengguna dari session
$id_pengguna = $_SESSION['user_id'];

// Ambil data pengguna saat ini
$sql = "SELECT * FROM pengguna WHERE id_pengguna = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$id_pengguna]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Cek jika pengguna tidak ditemukan
if (!$user) {
    header("Location: ../index.php?error=User tidak ditemukan");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Akun</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>Edit Akun Anda</h1>
        <form action="../controllers/edit_account_action.php" method="POST">
            <input type="hidden" name="id_pengguna" value="<?php echo $user['id_pengguna']; ?>">
            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo htmlspecialchars($user['nama']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="password">Password (kosongkan jika tidak ingin mengubah)</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
