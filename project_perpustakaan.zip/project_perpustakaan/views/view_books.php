<?php
include '../config/db.php';

// Ambil daftar buku dari database
$sql = "SELECT * FROM buku";
$stmt = $conn->query($sql);
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Proses penambahan buku
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_book'])) {
    $id_buku = $_POST['id_buku'];
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $id_rak = $_POST['id_rak'];

    // Pastikan untuk tidak memasukkan ID buku yang sudah ada
    $sql_add = "INSERT INTO buku (id_buku, judul, pengarang, tahun_terbit, id_rak) VALUES (?, ?, ?, ?, ?)";
    $stmt_add = $conn->prepare($sql_add);
    $stmt_add->execute([$id_buku, $judul, $pengarang, $tahun_terbit, $id_rak]);

    header("Location: view_books.php"); // Redirect setelah menambah buku
    exit();
}

// Proses penghapusan buku
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    $sql_delete = "DELETE FROM buku WHERE id_buku = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->execute([$delete_id]);

    header("Location: view_books.php"); // Redirect setelah menghapus buku
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa; /* Warna latar belakang */
        }
        .container {
            margin-top: 20px;
        }
        h1, h2 {
            color: #4B7BEC; /* Warna teks judul */
        }
        .btn-primary {
            margin-bottom: 15px; /* Jarak bawah untuk tombol tambah buku */
        }
        table {
            background-color: white; /* Warna latar tabel */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Daftar Buku</h1>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID Buku</th>
                    <th>Judul</th>
                    <th>Pengarang</th>
                    <th>Tahun Terbit</th>
                    <th>ID Rak</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($books as $book): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($book['id_buku']); ?></td>
                        <td><?php echo htmlspecialchars($book['judul']); ?></td>
                        <td><?php echo htmlspecialchars($book['pengarang']); ?></td>
                        <td><?php echo htmlspecialchars($book['tahun_terbit']); ?></td>
                        <td><?php echo htmlspecialchars($book['id_rak']); ?></td>
                        <td>
                            <a href="view_books.php?delete_id=<?php echo $book['id_buku']; ?>" 
                               class="btn btn-danger btn-sm" 
                               onclick="return confirm('Anda yakin ingin menghapus buku ini?');">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
        <!-- Tombol untuk tambah buku -->
        <h2>Tambah Buku</h2>
        <form action="view_books.php" method="POST" class="mb-4">
            <div class="form-row">
                <div class="form-group col-md-2">
                    <input type="text" name="id_buku" class="form-control" placeholder="ID Buku" required>
                </div>
                <div class="form-group col-md-3">
                    <input type="text" name="judul" class="form-control" placeholder="Judul" required>
                </div>
                <div class="form-group col-md-3">
                    <input type="text" name="pengarang" class="form-control" placeholder="Pengarang" required>
                </div>
                <div class="form-group col-md-2">
                    <input type="number" name="tahun_terbit" class="form-control" placeholder="Tahun Terbit" required>
                </div>
                <div class="form-group col-md-2">
                    <input type="text" name="id_rak" class="form-control" placeholder="ID Rak" required>
                </div>
                <div class="form-group col-md-2">
                    <button type="submit" name="add_book" class="btn btn-primary">Tambah Buku</button>
                </div>
            </div>
        </form>

            <!-- Tombol kembali ke admin dashboard -->
            <div class="text-center">
                    <a href="admin_dashboard.php" class="btn btn-danger">Kembali ke Dashboard Admin</a>
                </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
