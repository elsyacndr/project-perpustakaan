<?php
include '../config/db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM pengguna WHERE id_pengguna = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);

    header("Location: view_user.php");
}
?>
