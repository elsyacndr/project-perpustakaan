<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Hitung jumlah anggota (role 'user')
$sql_users = "SELECT COUNT(*) AS total_users FROM pengguna WHERE role = 'user'";
$stmt_users = $conn->query($sql_users);
$total_users = $stmt_users->fetch(PDO::FETCH_ASSOC)['total_users'];

// Hitung jumlah petugas (role 'admin')
$sql_admins = "SELECT COUNT(*) AS total_admins FROM pengguna WHERE role = 'admin'";
$stmt_admins = $conn->query($sql_admins);
$total_admins = $stmt_admins->fetch(PDO::FETCH_ASSOC)['total_admins'];

// Hitung jumlah buku
$sql_books = "SELECT COUNT(*) AS total_books FROM buku";
$stmt_books = $conn->query($sql_books);
$total_books = $stmt_books->fetch(PDO::FETCH_ASSOC)['total_books'];

// Hitung jumlah peminjaman
$sql_loans = "SELECT COUNT(*) AS total_loans FROM peminjaman";
$stmt_loans = $conn->query($sql_loans);
$total_loans = $stmt_loans->fetch(PDO::FETCH_ASSOC)['total_loans'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SI Perpus UNS - Dashboard Admin</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet"> <!-- Link ke file CSS kustom -->
    <style>
        /* CSS tambahan untuk memperindah tampilan */
        .sidebar-sticky h1 {
            font-size: 2rem; /* Perbesar ukuran huruf */
            font-weight: bold;
            color: #4B7BEC; /* Warna biru untuk membuat lebih menarik */
        }

        .sidebar-sticky h4 {
            margin-top: 30px; /* Beri jarak antar heading */
        }

        .sidebar-sticky ul {
            margin-top: 20px;
        }

        /* Styling untuk logo dan teks */
        .logo-title {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo-title img {
            width: 30px;
            height: 30px;
            margin-right: 10px; /* Jarak antara logo dan teks */
        }

        .sidebar {
            background-color: #f8f9fa; /* Background sidebar */
        }

        .nav-link {
            color: #343a40; /* Warna teks nav */
        }

        .nav-link:hover {
            background-color: #4B7BEC; /* Hover background color */
            color: white; /* Hover text color */
        }

        .sidebar h4 {
            color: #343a40; /* Warna heading section */
        }

        /* Styling untuk profile admin di kanan atas */
        .profile-admin {
            display: flex;
            align-items: center;
            justify-content: flex-end; /* Membuat elemen ke kanan */
        }

        .profile-admin img {
            width: 50px;
            height: 50px;
            margin-right: 10px;
            border-radius: 50%;
        }

        /* Dropdown untuk admin */
        .dropdown-menu-right {
            right: 0;
            left: auto;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <!-- Logo dan judul SIPERPUS UNS -->
                    <div class="logo-title text-center mt-3">
                        <img src="path/to/logo.png" alt="Logo"> <!-- Ganti dengan path logo yang benar -->
                        <h1 class="h4">SI Perpus UNS</h1>
                    </div>

                                    <h4 class="mt-4">MASTER DATA</h4>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="admin_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="view_user.php">Anggota</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="view_books.php">Buku</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="loan_book.php">Pinjam Buku</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transactions.php">Transaksi</a> <!-- Link ke halaman transaksi -->
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">Laporan</a> <!-- Link ke halaman laporan -->
                    </li>
                </ul>

                    <h4 class="mt-5">DOKUMENTASI</h4> <!-- Tambahkan margin untuk jarak -->
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="documentation.php">Memulai aplikasi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">Tentang aplikasi</a>
                        </li>
                    </ul>
                </div>
            </nav>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <!-- Profil Admin di sebelah kanan atas dengan dropdown menu -->
                    <div class="profile-admin ml-auto dropdown">
                    <span class="mr-3">
                        <?php 
                        if (isset($_SESSION['admin_name'])) {
                            echo $_SESSION['admin_name']; 
                        } else {
                            echo "Nama Admin"; // Jika admin_name belum di-set, tampilkan teks default
                        }
                        ?>
                    </span>

                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="path/to/profile.jpg" alt="Profile" class="img-thumbnail">
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="edit_account.php">Edit Akun</a>
                            <a class="dropdown-item" href="logout.php">Logout</a>
                            <a class="dropdown-item" href="add_user.php">Tambah Pengguna</a>
                        </div>
                    </div>
                </div>

                <h2>Dashboard</h2>
                <div class="row">
                    <div class="col-md-3">
                        <div class="card text-white bg-primary mb-3">
                            <div class="card-header">Jumlah Anggota</div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $total_users; ?></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-success mb-3">
                            <div class="card-header">Jumlah Petugas</div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $total_admins; ?></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-warning mb-3">
                            <div class="card-header">Jumlah Buku</div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $total_books; ?></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-danger mb-3">
                            <div class="card-header">Jumlah Peminjaman</div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $total_loans; ?></h5>
                            </div>
                        </div>
                    </div>
                </div>

                <h2 class="mt-5">Laporan Harian-Mingguan-Bulanan</h2>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Grafik Laporan</h5>
                                <!-- Tempatkan grafik di sini. Misalnya menggunakan Chart.js -->
                                <canvas id="myChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tambahkan script untuk grafik -->
                <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
                <script>
                    const ctx = document.getElementById('myChart').getContext('2d');
                    const myChart = new Chart(ctx, {
                        type: 'line', // Jenis grafik
                        data: {
                            labels: ['Hari 1', 'Hari 2', 'Hari 3'], // Ganti dengan data tanggal
                            datasets: [{
                                label: 'Jumlah Peminjaman',
                                data: [12, 19, 3], // Ganti dengan data peminjaman
                                borderColor: 'rgba(75, 192, 192, 1)',
                                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                </script>

            </main>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
