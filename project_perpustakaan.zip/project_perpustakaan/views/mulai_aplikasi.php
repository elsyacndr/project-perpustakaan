<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Memulai Aplikasi - SI Perpus UNS</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet"> <!-- Link ke file CSS kustom -->
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Panduan Memulai Aplikasi Perpustakaan</h1>
        
        <div class="card">
            <div class="card-body">
                <h3>Langkah-langkah Memulai Aplikasi</h3>
                <ol>
                    <li><strong>Login ke Aplikasi:</strong> Masukkan email dan password Anda di halaman login.</li>
                    <li><strong>Dashboard:</strong> Setelah login, Anda akan diarahkan ke halaman dashboard yang menunjukkan statistik perpustakaan, termasuk jumlah buku, anggota, dan peminjaman aktif.</li>
                    <li><strong>Menambah Buku:</strong> Admin dapat menambah buku baru melalui menu "Buku". Isikan judul, pengarang, tahun terbit, dan rak buku.</li>
                    <li><strong>Mengelola Anggota:</strong> Admin dapat melihat dan mengelola daftar anggota perpustakaan melalui menu "Anggota". Admin juga bisa menambah anggota baru.</li>
                    <li><strong>Memproses Peminjaman:</strong> Pengguna dapat meminjam buku yang tersedia. Admin dapat mengelola transaksi peminjaman melalui menu "Transaksi".</li>
                </ol>
                <h3>Fitur Tambahan</h3>
                <ul>
                    <li><strong>Notifikasi:</strong> Pengguna akan menerima notifikasi peminjaman dan pengembalian buku.</li>
                    <li><strong>Profil Pengguna:</strong> Pengguna dapat mengedit profil dan mengganti password melalui halaman profil.</li>
                </ul>
            </div>
        </div>

        <div class="text-center mt-4">
            <a href="admin_dashboard.php" class="btn btn-primary">Kembali ke Dashboard</a>
        </div>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
