<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Buku</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>Peminjaman Buku</h1>
        <form action="loan_action.php" method="POST">
            <div class="form-group">
                <select class="form-control" name="id_buku" required>
                    <option value="">Pilih Buku</option>
                    <?php
                    include '../config/db.php';
                    $sql = "SELECT * FROM buku";
                    $stmt = $conn->query($sql);
                    while ($book = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo "<option value='{$book['id_buku']}'>{$book['judul']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <select class="form-control" name="id_pengguna" required>
                    <option value="">Pilih Pengguna</option>
                    <?php
                    $sql = "SELECT * FROM pengguna";
                    $stmt = $conn->query($sql);
                    while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo "<option value='{$user['id_pengguna']}'>{$user['nama']}</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Pinjam Buku</button>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
