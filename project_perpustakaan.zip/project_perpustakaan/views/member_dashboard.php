<?php
session_start();
include '../config/db.php'; // Pastikan path ke file koneksi benar

// Ambil informasi pengguna dari session
$user_id = $_SESSION['user_id'];
$sql_user = "SELECT * FROM pengguna WHERE id_pengguna = :id_pengguna";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bindParam(':id_pengguna', $user_id);
$stmt_user->execute();
$user = $stmt_user->fetch(PDO::FETCH_ASSOC);

// Ambil data peminjaman buku
$sql_loans = "SELECT b.judul, p.tanggal_pinjam, p.tanggal_kembali FROM peminjaman p 
              JOIN buku b ON p.id_buku = b.id_buku 
              WHERE p.id_pengguna = :id_pengguna AND p.tanggal_kembali IS NULL";
$stmt_loans = $conn->prepare($sql_loans);
$stmt_loans->bindParam(':id_pengguna', $user_id);
$stmt_loans->execute();
$active_loans = $stmt_loans->fetchAll(PDO::FETCH_ASSOC);

// Ambil riwayat peminjaman
$sql_history = "SELECT b.judul, p.tanggal_pinjam, p.tanggal_kembali 
                FROM peminjaman p JOIN buku b ON p.id_buku = b.id_buku 
                WHERE p.id_pengguna = :id_pengguna";
$stmt_history = $conn->prepare($sql_history);
$stmt_history->bindParam(':id_pengguna', $user_id);
$stmt_history->execute();
$loan_history = $stmt_history->fetchAll(PDO::FETCH_ASSOC);

// Ambil absen
$sql_absen = "SELECT * FROM absen WHERE id_pengguna = :id_pengguna ORDER BY tanggal_absen DESC";
$stmt_absen = $conn->prepare($sql_absen);
$stmt_absen->bindParam(':id_pengguna', $user_id);
$stmt_absen->execute();
$absen_history = $stmt_absen->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Dashboard - Perpustakaan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-100">

    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <div class="w-1/4 bg-white p-5 shadow-lg">
            <div class="mb-10">
                <h2 class="text-xl font-semibold mb-4">SI Perpus UNS</h2>
                <div class="flex items-center">
                    <img src="https://via.placeholder.com/40" alt="User Image" class="rounded-full">
                    <div class="ml-4">
                        <h3 class="text-lg font-semibold"><?php echo $user['nama']; ?></h3>
                        <p class="text-sm text-gray-500">ID Anggota: <?php echo $user_id; ?></p>
                    </div>
                </div>
            </div>
            <nav>
                <a href="#" class="block py-2 px-4 bg-blue-100 text-blue-500 rounded-lg mb-4">Dashboard</a>
                <a href="#" class="block py-2 px-4 text-gray-600 rounded-lg mb-4">Peminjaman</a>
                <a href="#" class="block py-2 px-4 text-gray-600 rounded-lg">Profil</a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="w-3/4 p-10">
            <!-- Greeting -->
            <h1 class="text-2xl font-bold mb-6">Halo, <?php echo $user['nama']; ?>!</h1>

            <!-- Statistik Peminjaman dan Lama Membaca -->
            <div class="grid grid-cols-3 gap-4 mb-6">
                <div class="bg-white p-4 rounded-lg shadow">
                    <h3 class="text-lg font-semibold">Buku Pinjam</h3>
                    <div class="flex items-center mt-2">
                        <span class="text-3xl font-bold text-red-500">3/5</span>
                    </div>
                </div>
                <div class="bg-white p-4 rounded-lg shadow">
                    <h3 class="text-lg font-semibold">Buku Kembali</h3>
                    <div class="flex items-center mt-2">
                        <span class="text-3xl font-bold text-green-500">2/3</span>
                    </div>
                </div>
                <div class="bg-white p-4 rounded-lg shadow">
                    <h3 class="text-lg font-semibold">Lama Membaca</h3>
                    <div class="flex items-center mt-2">
                        <span class="text-3xl font-bold text-yellow-500">3j/hari</span>
                    </div>
                </div>
            </div>

            <!-- Buku yang Dipinjam -->
            <h2 class="text-xl font-semibold mb-4">Buku yang Dipinjam</h2>
            <table class="min-w-full bg-white shadow rounded-lg mb-6">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="py-2 px-4">Judul Buku</th>
                        <th class="py-2 px-4">Tanggal Pinjam</th>
                        <th class="py-2 px-4">Batas Kembali</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($active_loans as $loan): ?>
                    <tr>
                        <td class="py-2 px-4"><?php echo $loan['judul']; ?></td>
                        <td class="py-2 px-4"><?php echo $loan['tanggal_pinjam']; ?></td>
                        <td class="py-2 px-4"><?php echo $loan['tanggal_kembali']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Riwayat Peminjaman Buku -->
            <h2 class="text-xl font-semibold mb-4">Riwayat Peminjaman Buku</h2>
            <table class="min-w-full bg-white shadow rounded-lg">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="py-2 px-4">Judul Buku</th>
                        <th class="py-2 px-4">Tanggal Pinjam</th>
                        <th class="py-2 px-4">Tanggal Kembali</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($loan_history as $history): ?>
                    <tr>
                        <td class="py-2 px-4"><?php echo $history['judul']; ?></td>
                        <td class="py-2 px-4"><?php echo $history['tanggal_pinjam']; ?></td>
                        <td class="py-2 px-4"><?php echo $history['tanggal_kembali']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Absen Mengunjungi Perpustakaan -->
            <h4 class="text-xl font-semibold mb-4">Absen Mengunjungi Perpustakaan</h4>
            <form action="controllers/absen_action.php" method="POST">
                <input type="hidden" name="id_pengguna" value="<?php echo $user_id; ?>">
                <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded-lg">Absen Hari Ini</button>
            </form>
            <h5 class="mt-4">Riwayat Absen</h5>
            <ul class="list-disc ml-5">
                <?php foreach ($absen_history as $absen): ?>
                    <li><?php echo $absen['tanggal_absen']; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

</body>
</html>
