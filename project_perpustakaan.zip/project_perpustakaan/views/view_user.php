<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengguna</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>Daftar Pengguna</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th> <!-- Tambahkan kolom Role -->
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include '../config/db.php';
                $sql = "SELECT * FROM pengguna";
                $stmt = $conn->query($sql);
                while ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>
                            <td>{$user['id_pengguna']}</td>
                            <td>{$user['nama']}</td>
                            <td>{$user['email']}</td>
                            <td>{$user['role']}</td> <!-- Tampilkan role pengguna -->
                            <td>
                                <a href='edit_user.php?id={$user['id_pengguna']}' class='btn btn-warning'>Edit</a>
                                <a href='delete_user.php?id={$user['id_pengguna']}' class='btn btn-danger'>Hapus</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
