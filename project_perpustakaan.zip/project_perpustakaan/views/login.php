<?php
session_start();
include '../config/db.php'; // Pastikan path ke file koneksi benar

// Aktifkan error reporting untuk debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Cek apakah email ada di database
    $sql = "SELECT * FROM pengguna WHERE email = :email";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Jika pengguna ditemukan dan passwordnya benar
    if ($user && password_verify($password, $user['password'])) {
        // Simpan informasi pengguna ke session
        $_SESSION['user_id'] = $user['id_pengguna'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['user_name'] = $user['nama'];

        // Simpan tanggal login terakhir ke database
        $sql_update_login = "UPDATE pengguna SET last_login = NOW() WHERE id_pengguna = :id_pengguna";
        $stmt_update_login = $conn->prepare($sql_update_login);
        $stmt_update_login->bindParam(':id_pengguna', $user['id_pengguna']);
        $stmt_update_login->execute();

        // Redirect berdasarkan role
        if ($user['role'] == 'admin') {
            header("Location: ../views/admin_dashboard.php");
        }
        if ($user['role'] == 'user') {
            header("Location: ../views/member_dashboard.php");
        }
        exit();
    } else {
        // Jika login gagal, berikan pesan error
        $error = "Email atau password salah.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SI Perpus UNS</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f4f4f9;
            font-family: 'Poppins', sans-serif;
        }
        .login-container {
            margin-top: 100px;
            max-width: 400px;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .form-control {
            border-radius: 20px;
        }
        .btn-primary {
            width: 100%;
            border-radius: 20px;
            background-color: #5d5fef;
            border-color: #5d5fef;
        }
        .btn-primary:hover {
            background-color: #4b4bef;
        }
        .alert {
            border-radius: 20px;
        }
        .centered-content {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
    </style>
</head>
<body>

    <div class="centered-content">
        <div class="login-container">
            <h2>Login</h2>
            <?php if(isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
