<?php
session_start();
include '../config/db.php'; // Koneksi ke database

// Ambil data untuk grafik
// Pengunjung anggota
$sql_visitors = "SELECT COUNT(*) AS total_visitors FROM pengguna";
$stmt_visitors = $conn->query($sql_visitors);
$total_visitors = $stmt_visitors->fetchColumn();

$sql_new_users = "SELECT COUNT(*) AS total_new_users FROM pengguna WHERE DATE(tanggal_daftar) = CURDATE()";
$stmt_new_users = $conn->query($sql_new_users);
$total_new_users = $stmt_new_users->fetchColumn();

// Peminjam buku
$sql_monthly_loans = "SELECT MONTH(tanggal_pinjam) AS month, COUNT(*) AS total_loans FROM peminjaman GROUP BY MONTH(tanggal_pinjam)";
$stmt_monthly_loans = $conn->query($sql_monthly_loans);
$months = [];
$loan_counts = [];
while ($row = $stmt_monthly_loans->fetch(PDO::FETCH_ASSOC)) {
    $months[] = $row['month'];
    $loan_counts[] = $row['total_loans'];
}

// Hitung jumlah petugas yang hadir
$sql_attendance = "SELECT COUNT(*) AS total_attendance FROM pengguna WHERE role = 'admin'"; // Menghitung semua petugas
$stmt_attendance = $conn->query($sql_attendance);
$total_attendance = $stmt_attendance->fetch(PDO::FETCH_ASSOC)['total_attendance'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Peminjaman</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        h1 {
            color: #343a40;
        }
        .chart-container {
            position: relative;
            margin: auto;
            height: 60vh;
            width: 80vw;
        }
        .card {
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1>Laporan Peminjaman</h1>

        <!-- Filter Periode -->
        <div class="form-group">
            <label for="period">Pilih Periode:</label>
            <select id="period" class="form-control" onchange="updateCharts()">
                <option value="daily">Harian</option>
                <option value="weekly">Mingguan</option>
                <option value="monthly">Bulanan</option>
                <option value="yearly">Tahunan</option>
            </select>
        </div>

        <!-- Statistik Anggota -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Total Pengunjung Anggota</h5>
                <p class="card-text"><?php echo $total_visitors; ?></p>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Pengguna Baru</h5>
                <p class="card-text"><?php echo $total_new_users; ?></p>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Kehadiran Petugas</h5>
                <p class="card-text"><?php echo $total_attendance; ?></p>
            </div>
        </div>

        <!-- Grafik Peminjaman -->
        <div class="chart-container">
            <canvas id="loanChart"></canvas>
        </div>
        
        <script>
            const ctx = document.getElementById('loanChart').getContext('2d');
            const loanChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($months); ?>,
                    datasets: [{
                        label: 'Jumlah Peminjaman per Bulan',
                        data: <?php echo json_encode($loan_counts); ?>,
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 2,
                        fill: true,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            function updateCharts() {
                const selectedPeriod = document.getElementById('period').value;
                // Logika untuk memperbarui grafik berdasarkan periode yang dipilih
                // Anda perlu menambahkan AJAX atau fetch untuk mendapatkan data berdasarkan periode
            }
        </script>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
